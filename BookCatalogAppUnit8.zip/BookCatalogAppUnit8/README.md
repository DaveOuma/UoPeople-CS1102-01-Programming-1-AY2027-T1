# BookCatalogApp

## Requirements
- JDK 17 or newer
- Maven 3.9+ (or open this Maven project in IntelliJ IDEA and use the Maven wrapper if available)
- Internet access on the first build so Maven can download JavaFX dependencies

## Run
From this folder:
```bash
mvn clean javafx:run
```
In IntelliJ IDEA, open this folder as a Maven project, wait for dependency resolution, then run `BookCatalogApp.main()`.

## Features
- Encapsulated `Book` class with four private fields and constructors/getters/setters
- Four correctly bound TableView columns
- Add validation for non-empty title/author/ISBN, unique ISBN and ISBN-10/ISBN-13 checksum
- Remove selected book
- Check out / return selected book
- Live, case-insensitive title/author search using `FilteredList` and a Java Stream count
- CSV save/load with quoting for commas and quotation marks
- Load into a temporary list and validate before replacing the visible catalog

## Screenshot evidence
Run the application yourself and capture actual screenshots. Do not submit placeholder images as evidence. Suggested evidence:
1. `Test1`: add a book and show the filtered title/author result in the table.
2. `Test2`: show the selected book with Available set to false after checkout, then optionally capture it returned to true.
3. Optional: `Test3`: save, restart, load the CSV and show the restored records.

Use sample ISBNs that pass checksum validation, for example:
- 9780134685991 (ISBN-13)
- 0132350882 (ISBN-10)

